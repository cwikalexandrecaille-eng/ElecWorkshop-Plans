// Valeurs PUBLIQUES uniquement : remplacez-les depuis GitHub/Safari.
// Jamais de clé service_role ou de mot de passe ici.
window.EW_CONFIG = {
  supabaseUrl: 'https://uzrzjqwawynbievgxcdu.supabase.co',
  supabaseAnonKey: 'sb_publishable_P12TvU6CJ-5dq9hbnDrcaA_FOgGoT4C',
  companyName: 'Entreprise',
  companyLogoUrl: ''
};
